#include <Adafruit_Sensor.h> //Needed for sensors
#include <Adafruit_BME280.h> //Needed for BME280
#include <SparkFun_FS3000_Arduino_Library.h> //C lick here to get the library: http://librarymanager/All#SparkFun_FS3000

// BME definitons for I2C
#define SEALEVELPRESSURE_HPA (1013.25)
Adafruit_BME280 bme; // I2C
FS3000 fs3;

unsigned bme_status; //not sure what this does... might be able to remove

float temperature;
float pressure;
float airflow;

unsigned long lastTime = 0;
unsigned long timerDelay = 1000;  // send readings timer

void getSensorReadings(){
  temperature = (bme.readTemperature())*1.8 + 32;
  pressure = (bme.readPressure())/(10000);
  airflow = fs3.readMilesPerHour();
}
