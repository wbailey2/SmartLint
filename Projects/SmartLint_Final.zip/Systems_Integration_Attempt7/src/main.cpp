#include <Arduino.h> // Needed for all components
#include <Adafruit_Sensor.h> // Needed for sensors
#include <WiFi.h>
#include "Wire.h" // Needed for all components

// Header files
#include "communications.h"   // header file for WiFi and communications
#include "ESPAsyncWebServer.h" // Used to async update the webpage
#include "sendStrings.h" // Used to send strings to events on the webpage

// definitions for I2C Pins
#define I2C_SDA 15
#define I2C_SCL 4

void setup() {
  //turn on serial monitor
  Serial.begin(115200);

  // force wire to use our I2C pins
  Wire.begin(I2C_SDA, I2C_SCL);

  // initialize SPIFFS
  initSPIFFS();

  // load values saved in SPIFFS
  ssid = readFile(SPIFFS, ssidPath);
  pass = readFile(SPIFFS, passPath);
  ip = readFile(SPIFFS, ipPath);
  gateway = readFile (SPIFFS, gatewayPath);

  // print network information
  Serial.println(ssid);
  Serial.println(pass);
  Serial.println(ip);
  Serial.println(gateway);

  /* ----- INITIALIZE ACTUATOR PINS ----- */
  // initialize LEDs as outputs
  void ledInit();

  // initialize Piezo pin as output, sound buzzer once
  pinMode(19, OUTPUT);
  digitalWrite(19, HIGH);
  delay(500);
  digitalWrite(19, LOW);
  /* ------------------------------------ */

  /* ----- CHECK SENSOR STATUSES ----- */
  bool status1; // bme status check
  bool status2; // fs3000 status check

  // default settings
  // (you can also pass in a Wire library object like &Wire2)
  status1 = bme.begin(0x76);
  if (!status1) {
    Serial.println("Could not detect a BME280 sensor, Fix wiring Connections!");
    while (1);
  }
  else {
    Serial.println("BME280 connected.");
  }

  status2 = fs3.begin();
  if (!status2) {
    Serial.println("Could not detect a FS3000 sensor, Fix wiring Connections!");
    while (1);
  }
  else {
    Serial.println("FS3000 connected.");
  }
  /* ------------------------------- */

  /* ----- INITIALIZE WIFI, CONNECT DEVICE ----- */
  if(initWiFi()) {
    // Route for root / web page
    server.on("/", HTTP_GET, [](AsyncWebServerRequest *request) {
      request->send(SPIFFS, "/index.html", "text/html", false, processor);
    });
    server.serveStatic("/", SPIFFS, "/");

    // Handle Web Server
    server.on("/", HTTP_GET, [](AsyncWebServerRequest *request){
      request->send_P(200, "text/html", "/index.html", processor);
    });

    // Handle Web Server Events
    events.onConnect([](AsyncEventSourceClient *client){
      if(client->lastId()){
        Serial.printf("Client reconnected! Last message ID that it got is: %u\n", client->lastId());
      }
      // send event with message "hello!", id current millis
      // and set reconnect delay to 1 second
      client->send("hello!", NULL, millis(), 10000);
    });
    server.addHandler(&events);

    server.begin();
  }
  else {
    // Connect to Wi-Fi network with SSID and password
    Serial.println("Setting AP (Access Point)");
    // NULL sets an open Access Point
    WiFi.softAP("SMARTLINT WIFI-MANAGER", NULL);

    IPAddress IP = WiFi.softAPIP();
    Serial.print("AP IP address: ");
    Serial.println(IP);

    // Web Server Root URL
    server.on("/", HTTP_GET, [](AsyncWebServerRequest *request){
      request->send(SPIFFS, "/wifimanager.html", "text/html");
    });

    server.serveStatic("/", SPIFFS, "/");

    server.on("/", HTTP_POST, [](AsyncWebServerRequest *request) {
      int params = request->params();
      for(int i=0;i<params;i++){
        AsyncWebParameter* p = request->getParam(i);
        if(p->isPost()){
          // HTTP POST ssid value
          if (p->name() == PARAM_INPUT_1) {
            ssid = p->value().c_str();
            Serial.print("SSID set to: ");
            Serial.println(ssid);
            // Write file to save value
            writeFile(SPIFFS, ssidPath, ssid.c_str());
          }
          // HTTP POST pass value
          if (p->name() == PARAM_INPUT_2) {
            pass = p->value().c_str();
            Serial.print("Password set to: ");
            Serial.println(pass);
            // Write file to save value
            writeFile(SPIFFS, passPath, pass.c_str());
          }
          // HTTP POST ip value
          if (p->name() == PARAM_INPUT_3) {
            ip = p->value().c_str();
            Serial.print("IP Address set to: ");
            Serial.println(ip);
            // Write file to save value
            writeFile(SPIFFS, ipPath, ip.c_str());
          }
          // HTTP POST gateway value
          if (p->name() == PARAM_INPUT_4) {
            gateway = p->value().c_str();
            Serial.print("Gateway set to: ");
            Serial.println(gateway);
            // Write file to save value
            writeFile(SPIFFS, gatewayPath, gateway.c_str());
          }
          //Serial.printf("POST[%s]: %s\n", p->name().c_str(), p->value().c_str());
        }
      }
      request->send(200, "text/plain", "Done. ESP will restart, connect to your router and go to IP address: " + ip);
      delay(3000);
      ESP.restart();
    });
    server.begin();
  }
} // end setup()

void loop() { // begin loop()
  if ((millis() - lastTime) > timerDelay) {
    // reset counting variables
    reset_counts();

    // read sensors
    getSensorReadings();

    // run logic
    logic();

    // Send Events to the Web Server with the Sensor Readings
    events.send("ping",NULL,millis());
    events.send(String(ledstatus).c_str(),"ledstatus",millis());
    events.send(String(temperature).c_str(),"temperature",millis());
    events.send(String(pressure).c_str(),"pressure",millis());
    events.send(String(airflow).c_str(),"airflow",millis());

    lastTime = millis();
  }
}
