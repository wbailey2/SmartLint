#include "logic.h" //take the values from the logic file and convert to strings for website use

String processor(const String& var){
  getSensorReadings();

  if(var == "TEMPERATURE"){
    return String(temperature);
  }
  else if(var == "PRESSURE"){
    return String(pressure);
  }
  else if(var == "AIRFLOW"){
    return String(airflow);
  }
  else if(var == "LEDSTATUS"){
    return String(ledstatus);
  }
}
