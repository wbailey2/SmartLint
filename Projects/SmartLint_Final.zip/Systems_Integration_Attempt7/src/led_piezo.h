#include "analogWrite.h" // Needed for LED Test

// LED PIN definitions
#define PIN_RED    16 // GPIO16
#define PIN_GREEN  17 // GPIO17
#define PIN_BLUE   18 // GPIO18

// initialize LED pins as outputs
void ledInit(){
  pinMode(PIN_RED,   OUTPUT);
  pinMode(PIN_GREEN, OUTPUT);
  pinMode(PIN_BLUE,  OUTPUT);
}
