#include "led_piezo.h" //use LED pins
#include "sensorsReading.h" //use sensor values

/* ----- DEFINITIONS ----- */
#define OFF 0
#define ON 1

#define GOOD 0
#define BAD 1
#define UGLY 2

// for writing to website
const char* ledstatus;

// dryer control variable
bool dryer_on_off;

// for counting number of flags
int count_good;
int count_bad;
int count_ugly;

// bme280
float temp_th_high = 120; // ºF
float temp_th_low = 110; // ºF
float pres_th_high = 51.3; // hPa
float pres_th_low = 17.5; // ARBITRARY, hPa

// fs3000
float airflow_th_high = 13.67; // mph
float airflow_th_low = 9.84; // mph
float airflow_th_min = 3.28; // mph

// flags to indicate a threshold is exceeded
int temp_flag;
int pres_flag;
int airflow_flag;

/* ----- END DEFINITIONS ----- */

/* ----- LOGIC ----- */
void reset_counts(){
  count_good = 0;
  count_bad = 0;
  count_ugly = 0;
}

void logic() {
  if(airflow > airflow_th_min){ // dryer is running
    // delay to let dryer start up
    delay(5000); // 5 sec
    if (airflow >= airflow_th_high) {
      airflow_flag = GOOD;
      count_good++;
    }
    else if ((airflow >= airflow_th_low) && (airflow < airflow_th_high)) {
      airflow_flag = BAD;
      count_bad++;
    }
    else {
      airflow_flag = UGLY;
      count_ugly++;
    }

    // temperature
    if (temperature >= temp_th_high) {
      temp_flag = UGLY;
      count_ugly++;
    }
    else if ((temperature >= temp_th_low) && (temperature < temp_th_high)) {
      temp_flag = BAD;
      count_bad++;
    }
    else {
      temp_flag = GOOD;
      count_good++;
    }

    // pressure
    if (pressure >= pres_th_high) {
      pres_flag = UGLY;
      count_ugly++;
    }
    else if ((pressure >= pres_th_low) && (pressure < pres_th_high)) {
      pres_flag = BAD;
      count_bad++;
    }
    else {
      pres_flag = GOOD;
      count_good++;
    }

    // actuation
    if (count_ugly >= 1) {
      // turn on red LED
      analogWrite(PIN_RED, 255);
      analogWrite(PIN_GREEN, 0);
      analogWrite(PIN_BLUE, 0);

      // turn on buzzer
      digitalWrite(19, HIGH);
      delay(500);
      digitalWrite(19, LOW);

      // write status to website
      ledstatus = "EMERGENCY, STOP DRYER AND CHECK VENTILATION FOR LINT!";
    }
    else if (count_bad >= 1) {
      // turn on yellow LED
      analogWrite(PIN_RED, 255);
      analogWrite(PIN_GREEN, 255);
      analogWrite(PIN_BLUE, 0);

      // write status to website
      ledstatus = "Potential issue detected. Clean lint trap and check ventilation pipe.";
    }
    else {
      // turn on green LED
      analogWrite(PIN_RED, 0);
      analogWrite(PIN_GREEN, 255);
      analogWrite(PIN_BLUE, 0);

      // write status to website
      ledstatus = "Dryer running. No issues detected.";
    }
  }
  else {
    // dryer is off
    // turn off LED
    analogWrite(PIN_RED, 0);
    analogWrite(PIN_GREEN, 0);
    analogWrite(PIN_BLUE, 0);

    ledstatus = "Dryer not running.";
  }
}
/* ----- END LOGIC ----- */
